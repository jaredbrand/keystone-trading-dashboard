# ⚡ QUICK START - 5 MINUTE SETUP

## What You Need
1. Google Sheets API Key (5 min to get)
2. GitHub account (free)
3. The ZIP file I provided

## Setup in 3 Steps

### STEP 1: Get API Key (5 min)
```
1. Go to: https://console.cloud.google.com/
2. Create new project: "keystone-dashboard"
3. Search: "Google Sheets API" → Enable it
4. Create Credentials → API Key
5. Restrict to: Google Sheets API only
6. Copy your key (looks like: AIzaSyD...)
```

### STEP 2: Update Code (1 min)
```
1. Extract the ZIP file
2. Open: src/App.jsx
3. Line 24: Replace YOUR_GOOGLE_API_KEY_HERE with your actual key
4. Save the file
```

### STEP 3: Deploy (5 min)
```
Option A - Vercel (Recommended):
1. Go to: https://vercel.com
2. Sign in with GitHub
3. New Project → Import from GitHub
4. Upload the folder
5. Framework: Vite
6. Deploy!

Option B - Netlify:
1. Go to: https://netlify.com
2. Drag & drop the folder
3. Done!
```

## 🎯 Your Dashboard URL
```
https://keystone-trading-dashboard.vercel.app
or
https://your-site-name.netlify.app
```

## ✅ Verify It Works
- Open the URL
- Should see "Loading Dashboard..."
- Then your data appears
- Auto-refreshes every 60 seconds

## 🔧 Troubleshooting
```
Error: "Failed to fetch"
→ Check API key is correct
→ Make sure Google Sheet is public (Anyone with link can view)

Error: "Loading forever"
→ Check Sheet ID in src/App.jsx line 23
→ Verify tab names: bets_week_1, DailyPNL, SummaryStats
```

## 📱 Access Your Dashboard
```
Works on:
✅ Desktop computers
✅ Tablets  
✅ Mobile phones
✅ Any web browser

Just bookmark the URL!
```

## 🎨 Cool Features
- Toggle views: All / Bets / Daily / Summary
- Filter dates: All Time / 30 Days / 7 Days
- Manual refresh button (⟳)
- Auto-refresh every 60 seconds
- See open positions in yellow
- Candlestick chart with volume bars
- Real-time P&L tracking

## 📞 Need More Help?
See full guide: SETUP_GUIDE.md (in the ZIP file)

---

**That's it! Your professional trading dashboard is live! 🚀**
